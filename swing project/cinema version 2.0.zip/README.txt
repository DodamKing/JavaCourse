sqlite를 이용한 
swing 프로젝트
배포 테스트용